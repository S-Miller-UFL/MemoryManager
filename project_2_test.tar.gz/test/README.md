How to use these tests

1. Place the `test/` directory in the same directory as `MemoryManager/`
(e.g.: If you have `~/p2/MemoryManager/`, then place the `test/` in the `~/p2/` directory)

2. `cd` into the `test/` directory and run `make && ./test`.
